# Stryde — Roblox & Discord için DPI Bypass (Türkiye)

GoodbyeDPI'ı yöneten, siyah/altın arayüzlü bir Windows uygulaması. Amaç: Roblox ve Discord'a
takılmadan girmek, profil resimlerinin yüklenmesi ve GoodbyeDPI'ın yol açtığı kasmayı bitirmek.

## Kurulum

1. `dist\Stryde.exe` dosyasını (yanındaki `engine\` klasörüyle birlikte) istediğin yere kopyala,
   örneğin `C:\Stryde\`.
2. `Stryde.exe`'ye çift tıkla. Yönetici izni ister (WinDivert sürücüsü için zorunlu).
3. Açılışta otomatik bağlanır; sağdaki **Servis Durumu** paneli 9 Roblox/Discord servisini test eder.

Antivirüs `engine\WinDivert64.sys` dosyasını yanlış pozitif sayarsa `engine` klasörünü dışlamalara ekle.

## Kasma ve profil resmi sorunu neden çözülüyor?

* Eski kurulum (`turkey_dnsredir.cmd`) **tüm** HTTPS trafiğini parçalıyor ve `--set-ttl 5` ile her
  bağlantıya sahte paket gönderiyordu. Stryde varsayılan olarak **sadece** listedeki alan adlarına
  (`roblox.com`, `rbxcdn.com`, `discord.com`, ...) müdahale eder (`--blacklist`); oyun, YouTube,
  Steam vb. trafiğe hiç dokunmaz.
* Profil resimleri `*.rbxcdn.com` sunucularından gelir; bu alan adı listede olduğu için artık
  parçalama uygulanır ve resimler yüklenir. **Servis Durumu** panelinde "Roblox CDN (resimler)" satırı
  yeşilse sorun yok demektir.
* **Otomatik Optimize** 7 modu sırayla dener, 9 servisi test eder, tam puan alan **en hafif** modu
  seçer ve kaydeder. Hattın değişirse (modem, ISS) bir daha bas.

## VPN (Cloudflare WARP)

VPN sayfası, WireGuard üzerinden Cloudflare WARP tüneli kurar: ücretsiz, hesapsız, tüm trafik şifreli.
İlk kullanımda "WireGuard'ı kur" düğmesi resmi `wireguard-amd64-0.5.3.msi` dosyasını
`download.wireguard.com` adresinden indirip sessizce kurar (yaklaşık 5 MB). Sonra "VPN'i Aç" bir tıkla
Cloudflare'a cihaz kaydı yapar (`api.cloudflareclient.com`), yapılandırmayı `C:\ProgramData\Stryde\vpn\`
altına yazar ve `WireGuardTunnel$StrydeWARP` hizmetini başlatır. Durum `cloudflare.com/cdn-cgi/trace`
ile doğrulanır (`warp=on`).

* VPN oyun ping'ini artırabilir: oyun için DPI modu yeterli, VPN'i gerektiğinde aç.
* Varsayılan uç nokta UDP 2408 yavaşsa sayfadaki diğer portları (500, 1701, 4500) dene.
* Bir VPN sağlayıcının `.conf` dosyasını içe aktarıp WARP yerine onu da kullanabilirsin.
* Stryde kapansa bile VPN hizmeti çalışmaya devam eder; kapatmak için "VPN'i Kapat".

## Sürüm notları

**v1.1**
* Şifreli DNS (DoH): Stryde içinde 127.0.0.1:53 sunucusu, Google/Cloudflare'a IP üzerinden HTTPS; Windows DNS'i bağlıyken 127.0.0.1, kesince geri alınır, çökme sonrası kurtarma; her 30 sn doğrulama ve onarım.
* Otomatik optimize 2 turlu, iptal edilebilir; başlatıcı ve küçük resim sunucuları test listesinde (11 servis, gruplu liste).
* Ağ değişikliğinde (kablo, Wi-Fi, uyku dönüşü) otomatik yeniden doğrulama.
* Tepsi simgesinde durum rengi; tepsiden servis testi.
* Yeniden boyutlandırılabilir pencere, sayfa geçiş animasyonu, animasyonlu anahtarlar, meşgul çubuğu, ilk kurulum ipucu.
* Günlük sayfasında tek tıkla tanı raporu (sistem, DNS, motor, servisler, son olaylar).
* Dış IP göstergesi (doğrudan / WARP üzerinden).
* VPN sayfası: Cloudflare WARP (WireGuard), uç nokta seçimi, özel .conf.

## Uygulama içi güncelleme

Stryde, Ayarlar → Güncellemeler'deki **sürüm dosyası linkini** açılışta ve 6 saatte bir okur. Yeni sürüm varsa
panelde yeşil şerit çıkar; "Güncelle" zip'i indirir, SHA-256 ile doğrular, Stryde'ı kapatıp dosyaları
üzerine yazar ve yeniden açar (DNS önce geri alınır).

Yayıncı adımları (her sürümde):
1. `Stryde-vX.Y.zip` dosyasını Google Drive'a yükle, "bağlantıya sahip herkes" yap, linki kopyala.
2. `Stryde-version.json` dosyasını düzenle: `version`, `url` (Drive linki), `sha256` (`Get-FileHash` ile), `notes`.
3. `Stryde-version.json`'ı da Drive'a yükle (aynı dosyayı her sürümde üzerine yaz ki linki değişmesin), "herkese açık" yap.
4. Bu JSON linki kullanıcıların Ayarlar → Güncellemeler alanında olmalı; dağıtılan sürümde varsayılan olarak gömülüdür.

Drive paylaşım linkleri (`/file/d/<id>/view`) otomatik olarak doğrudan indirme adresine çevrilir.

## Sayfalar

| Sayfa | Ne yapar |
|---|---|
| Panel | Güç düğmesi, servis testi, hızlı eylemler |
| Modlar | 7 GoodbyeDPI modu, kapsam anahtarı, ek parametreler |
| Alan Adları | Müdahale edilecek alan adı listesi (her satıra bir tane) |
| Ayarlar | Açılışta bağlan, Windows ile başlat, tepsi, DNS yönlendirme, eski hizmeti kaldırma |
| Günlük | Motor çıktısı ve olaylar (`%AppData%\Stryde\stryde.log`) |

## Komut satırı

| Parametre | Anlamı |
|---|---|
| `--minimized` | Tepsiye küçük başlar (Windows ile başlat bunu kullanır) |
| `--no-elevate` | Yönetici istemeden sadece arayüzü açar (geliştirme) |
| `--screenshot dosya.png --page dash\|modes\|domains\|settings\|log` | Sayfayı PNG'ye çizer ve çıkar (geliştirme) |

## Derleme

.NET 8 SDK gerekir. `build.ps1` çalıştır; çıktı `dist\Stryde.exe` + `dist\engine\`.

## Notlar

* Stryde açıkken başka bir GoodbyeDPI kopyası (eski `.cmd` penceresi veya hizmet) varsa bağlanırken
  kapatılır; iki kopya aynı anda çalışırsa paketler iki kez parçalanır ve bağlantı bozulur.
* Stryde kapanınca motor da kapanır (Job Object). Tepsiye küçültmek motoru kapatmaz.
* GoodbyeDPI VPN değildir; sadece TCP 80/443 paketlerini DPI'ın tanıyamayacağı şekle sokar.
  Oyun içi UDP trafiğine hiç dokunmaz, ping'i değiştirmez.
